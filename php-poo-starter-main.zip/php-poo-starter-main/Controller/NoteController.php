<?php

namespace Controller;

class NoteController
{
    /**
     * Execution du script pour récupérer toutes les notes
     */
    public function getAll()
    {}

    /**
     * Execution du script pour récupérer une note spécifique
     */
    public function getOne()
    {}

    /**
     * Execution du script pour créer une note
     */
    public function create()
    {}

    /**
     * Execution du script pour mettre à jour une note existante
     */
    public function update()
    {}

    /**
     * Execution du script pour supprimer une note existante
     */
    public function delete()
    {}
}
// Ne rien écrire après cette accolade